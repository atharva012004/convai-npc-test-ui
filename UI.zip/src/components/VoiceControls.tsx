import type { UiState } from '../types/conversation';

interface Props {
  state: UiState;
  onStart: () => void;
  onStop: () => void;
}

export function VoiceControls({ state, onStart, onStop }: Props) {
  const canStart = state === 'IDLE' || state === 'COMPLETED' || state === 'ERROR';
  const canStop = !canStart && state !== 'STOPPING' && state !== 'SAVING_TRANSCRIPT';

  return (
    <div className="controls-row">
      <button className="primary-button start-button" onClick={onStart} disabled={!canStart}>
        <span className="button-icon">▶</span>
        <span><strong>Start conversation</strong><small>Authenticate backend access</small></span>
      </button>
      <button className="secondary-button stop-button" onClick={onStop} disabled={!canStop}>
        <span className="button-icon">■</span>
        <span><strong>End conversation</strong><small>Save transcript & close</small></span>
      </button>
    </div>
  );
}
