import { parseExpiration } from './expiration';
import { useCallback, useEffect, useRef, useState } from 'react';
import { getFreshGameAssertion } from '../api/devAssertionApi';
import { getConvaiToken } from '../api/convaiApi';
import { bootstrapSessionForIdentity, endSession } from '../api/sessionApi';
import { sendDirectConversation } from '../api/directConversationApi';
import { env } from '../config/env';
import {
  applyDynamicContext,
  connectConvai,
  createConvaiClient,
  disconnectConvai,
  interruptCurrentResponse,
  shouldInterruptForExplicitUserTurn,
  subscribeConvai,
  type ConvaiClientInstance,
} from '../convai/convaiClient';
import type { ConvaiMessageLike, ConvaiStateLike } from '../types/convai';
import type { SessionStartResponse } from '../types/backend';
import type { ConversationMessage, Diagnostics, UiState } from '../types/conversation';
import { appendConvaiMessage } from '../state/convaiMessagePresentation';
import { ApiError } from '../api/backendClient';

const STARTUP_DEADLINE_MS = 45_000;
const RECENT_DUPLICATE_WINDOW_MS = 4_000;

function safeErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 401) return 'Backend authentication expired or was rejected. Start a fresh conversation.';
    if (error.status === 403) return 'The current actor/character is not authorized for this backend session.';
    if (error.status === 429) return 'The backend rate limit was reached. Wait briefly and try again.';
    if (error.status >= 500) return 'The backend is temporarily unavailable. Check the backend logs and try again.';
    return error.message;
  }
  if (error instanceof Error) return error.message;
  return 'The conversation could not be processed.';
}

async function fingerprintText(text: string): Promise<string> {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest)).slice(0, 8).map((value) => value.toString(16).padStart(2, '0')).join('');
}

export function useConversation() {
  const [uiState, setUiState] = useState<UiState>('IDLE');
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [session, setSession] = useState<SessionStartResponse | null>(null);
  const [convaiClient, setConvaiClient] = useState<ConvaiClientInstance | null>(null);
  const [convaiCharacterId, setConvaiCharacterId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [transcriptSaveMessage, setTranscriptSaveMessage] = useState<string | null>(null);
  const [diagnostics, setDiagnostics] = useState<Diagnostics>({
    backend: 'unknown', bootstrap: 'idle', sessionStart: 'idle', context: 'idle', contextApplied: 'no',
    contextFingerprint: null, convaiAuth: 'idle', convai: 'idle', transcript: 'idle', startupMs: null,
    messageCount: 0, memoryCount: 0, narrativeCount: 0, knowledgeCount: 0, selectedCount: 0,
    droppedCount: 0, contextTokens: null, contextRefreshes: 0, lastQuestion: null,
    conversationRuntime: 'not-started',
  });

  const clientRef = useRef<ConvaiClientInstance | null>(null);
  const unsubscribeRef = useRef<(() => void) | null>(null);
  const backendTokenRef = useRef<string | null>(null);
  const backendTokenExpiresAtRef = useRef<number | null>(null);
  const sessionIdRef = useRef<string | null>(null);
  const transcriptRef = useRef<ConversationMessage[]>([]);
  const lifecycleIdRef = useRef(0);
  const questionInFlightRef = useRef(false);
  const stoppingRef = useRef(false);
  const contextAppliedRef = useRef(false);
  const currentActorTurnIdRef = useRef<string | null>(null);
  const activeNpcResponseActorIdRef = useRef<string | null>(null);
  const responseStartedForCurrentActorRef = useRef(false);
  const recentSubmissionRef = useRef<{ key: string; at: number } | null>(null);

  useEffect(() => {
    transcriptRef.current = messages;
    setDiagnostics((current) => ({ ...current, messageCount: messages.length }));
  }, [messages]);

  const clearConvai = useCallback(async () => {
    unsubscribeRef.current?.();
    unsubscribeRef.current = null;
    const client = clientRef.current;
    clientRef.current = null;
    setConvaiClient(null);
    if (client) {
      try { await disconnectConvai(client); } catch { /* best-effort cleanup */ }
    }
  }, []);

  const resetRuntime = useCallback(() => {
    setMessages([]);
    setSession(null);
    setError(null);
    setTranscriptSaveMessage(null);
    backendTokenRef.current = null;
    backendTokenExpiresAtRef.current = null;
    sessionIdRef.current = null;
    questionInFlightRef.current = false;
    contextAppliedRef.current = false;
    currentActorTurnIdRef.current = null;
    activeNpcResponseActorIdRef.current = null;
    responseStartedForCurrentActorRef.current = false;
    recentSubmissionRef.current = null;
    setDiagnostics({
      backend: 'unknown', bootstrap: 'idle', sessionStart: 'idle', context: 'idle', contextApplied: 'no',
      contextFingerprint: null, convaiAuth: 'idle', convai: 'idle', transcript: 'idle', startupMs: null,
      messageCount: 0, memoryCount: 0, narrativeCount: 0, knowledgeCount: 0, selectedCount: 0,
      droppedCount: 0, contextTokens: null, contextRefreshes: 0, lastQuestion: null,
      conversationRuntime: 'not-started',
    });
  }, []);

  const start = useCallback(async () => {
    if (uiState !== 'IDLE' && uiState !== 'COMPLETED' && uiState !== 'ERROR') return;
    const lifecycleId = ++lifecycleIdRef.current;
    stoppingRef.current = false;
    await clearConvai();
    resetRuntime();
    setUiState('STARTING_BACKEND_SESSION');

    const startedAt = performance.now();
    const controller = new AbortController();
    const deadline = window.setTimeout(() => controller.abort(), STARTUP_DEADLINE_MS);

    try {
      const assertion = await getFreshGameAssertion();
      const bootstrap = await bootstrapSessionForIdentity(
        assertion,
        env.characterExternalId,
        env.actorExternalId,
        controller.signal,
      );
      if (lifecycleId !== lifecycleIdRef.current) return;
      backendTokenRef.current = bootstrap.access_token;
      backendTokenExpiresAtRef.current = bootstrap.expires_at * 1000;
      setDiagnostics((current) => ({
        ...current,
        backend: 'connected', bootstrap: 'success', sessionStart: 'idle',
        convaiAuth: 'pending', convai: 'initializing', transcript: 'collecting',
        startupMs: Math.round(performance.now() - startedAt),
      }));

      const convaiToken = await getConvaiToken(
        bootstrap.access_token,
        env.characterExternalId,
        env.actorExternalId,
        controller.signal,
      );
      if (lifecycleId !== lifecycleIdRef.current) return;
      const expirationMs = parseExpiration(convaiToken.expiration_time);
      if (expirationMs !== null && expirationMs <= Date.now()) throw new Error('The backend returned an already-expired Convai token.');
      setDiagnostics((current) => ({ ...current, convaiAuth: 'received' }));

      const client = createConvaiClient();
      clientRef.current = client;
      setConvaiClient(client);
      setConvaiCharacterId(convaiToken.convai_character_id);

      unsubscribeRef.current = subscribeConvai(client, {
        onStateChange: (state: ConvaiStateLike) => {
          if (lifecycleId !== lifecycleIdRef.current) return;
          if (state.isThinking || state.isSpeaking) responseStartedForCurrentActorRef.current = true;
          setDiagnostics((current) => ({
            ...current,
            convai: state.isConnected ? 'connected' : current.convai,
            conversationRuntime: state.isConnected ? 'single-convai-client' : current.conversationRuntime,
          }));
          if (questionInFlightRef.current) return;
          if (state.isSpeaking) setUiState('NPC_SPEAKING');
          else if (state.isListening && contextAppliedRef.current) setUiState('LISTENING');
          else if (state.isConnected && contextAppliedRef.current) setUiState('READY');
        },
        onMessage: (incoming: ConvaiMessageLike) => {
          if (lifecycleId !== lifecycleIdRef.current || !incoming.content?.trim()) return;
          // The browser speech gate owns the final player line. Convai's user
          // transcription transport is intentionally ignored to prevent a
          // second visual turn for one question.
          if (incoming.type === 'user-transcription' || incoming.type === 'user-llm-text') return;
          if (incoming.type !== 'bot-llm-text' && incoming.type !== 'bot-transcription') return;
          const actorId = currentActorTurnIdRef.current;
          if (!actorId || !responseStartedForCurrentActorRef.current) return;
          if (activeNpcResponseActorIdRef.current === null) activeNpcResponseActorIdRef.current = actorId;
          if (activeNpcResponseActorIdRef.current !== actorId) return;
          setMessages((current) => appendConvaiMessage(current, incoming));
        },
        onUserTranscriptionChange: () => undefined,
        onError: (convaiError: Error) => {
          if (lifecycleId !== lifecycleIdRef.current) return;
          setDiagnostics((current) => ({ ...current, convai: 'error' }));
          setError(`Convai error: ${convaiError.message}`);
          setUiState('ERROR');
        },
      });

      setUiState('CONNECTING_CONVAI');
      await connectConvai(client, convaiToken.api_auth_token, convaiToken.convai_character_id, convaiToken.end_user_id);
      if (lifecycleId !== lifecycleIdRef.current) return;
      clearTimeout(deadline);
      setDiagnostics((current) => ({
        ...current,
        convai: 'connected',
        conversationRuntime: 'single-convai-client',
        startupMs: Math.round(performance.now() - startedAt),
      }));
      setUiState('READY');
    } catch (caughtError) {
      clearTimeout(deadline);
      if (lifecycleId !== lifecycleIdRef.current) return;
      setError(controller.signal.aborted ? 'Conversation startup exceeded the 45-second local startup deadline.' : safeErrorMessage(caughtError));
      setDiagnostics((current) => ({
        ...current,
        backend: current.bootstrap === 'success' ? current.backend : 'error',
        bootstrap: current.bootstrap === 'pending' ? 'error' : current.bootstrap,
        convaiAuth: current.convaiAuth === 'pending' ? 'error' : current.convaiAuth,
        convai: current.convai === 'connected' ? current.convai : 'error',
      }));
      setUiState('ERROR');
      await clearConvai();
    }
  }, [clearConvai, resetRuntime, uiState]);

  const sendText = useCallback(async (text: string) => {
    const trimmed = text.trim();
    const client = clientRef.current;
    const token = backendTokenRef.current;
    if (!trimmed || !client || !token || !client.state.isConnected || questionInFlightRef.current) return;
    if (backendTokenExpiresAtRef.current !== null && backendTokenExpiresAtRef.current <= Date.now()) {
      setError('The backend session token has expired. Start a fresh conversation.');
      setUiState('ERROR');
      return;
    }
    const key = trimmed.replace(/\s+/g, ' ').toLocaleLowerCase();
    const now = Date.now();
    const recent = recentSubmissionRef.current;
    if (recent && recent.key === key && now - recent.at < RECENT_DUPLICATE_WINDOW_MS) return;
    recentSubmissionRef.current = { key, at: now };

    questionInFlightRef.current = true;
    setError(null);
    setUiState('REFRESHING_CONTEXT');
    try {
      if (shouldInterruptForExplicitUserTurn(client.state)) {
        activeNpcResponseActorIdRef.current = null;
        responseStartedForCurrentActorRef.current = false;
        interruptCurrentResponse(client);
      }

      // This single API call is the authoritative per-question gate. It creates
      // the session on the first question and reuses the same active session on
      // every later question. It never asks the backend LLM for a second answer.
      const result = await sendDirectConversation(
        token,
        env.characterExternalId,
        env.actorExternalId,
        trimmed,
        false,
      );
      if (!sessionIdRef.current) sessionIdRef.current = result.session_id;

      const runtime = result.runtime;
      const contextText = runtime?.dynamic_context_text ?? '';
      if (runtime?.context_status === 'failed' || runtime?.context_status === 'cancelled') {
        throw new Error(`Backend Dynamic Context is ${runtime.context_status}; the question was not sent to Convai.`);
      }

      const fingerprint = await fingerprintText(contextText);
      await applyDynamicContext(client, contextText);
      contextAppliedRef.current = true;

      const dynamicContext = {
        status: (runtime?.context_status ?? 'complete') as 'complete' | 'partial' | 'empty' | 'failed' | 'cancelled',
        memory: [], narrative: [], knowledge: [], policy_version: null,
        selected_count: runtime?.selected_count ?? 0,
        dropped_count: runtime?.dropped_count ?? 0,
        conflict_groups: [],
        budget_usage: { selected_tokens: runtime?.context_tokens ?? 0 },
        metadata: {},
        text: contextText,
      };
      setSession((current) => current ?? ({
        id: result.session_id,
        character_id: '', actor_id: '', status: 'active', started_at: new Date().toISOString(),
        context: {
          project: { id: '', name: 'Direct conversation' },
          character: { id: '', external_id: result.character_external_id, convai_character_id: convaiCharacterId, base_personality: null, config: {} },
          actor: { id: '', external_id: env.actorExternalId, meta: {} }, relationship: null, narrative: null,
          knowledge: null, memory: null, session: { id: result.session_id, status: 'active', started_at: new Date().toISOString(), ended_at: null },
          dynamic_context: dynamicContext,
        },
      }));
      setSession((current) => current ? { ...current, context: { ...current.context, dynamic_context: dynamicContext } } : current);

      const actorTurn: ConversationMessage = {
        id: `actor-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        speaker: 'actor', text: trimmed, timestamp: new Date().toISOString(),
      };
      currentActorTurnIdRef.current = actorTurn.id;
      activeNpcResponseActorIdRef.current = null;
      responseStartedForCurrentActorRef.current = false;
      setMessages((current) => [...current, actorTurn]);

      setDiagnostics((current) => ({
        ...current,
        backend: 'connected', sessionStart: 'success', lastQuestion: trimmed,
        context: runtime?.context_status === 'complete' ? 'complete' : runtime?.context_status === 'partial' ? 'partial' : runtime?.context_status === 'empty' ? 'empty' : 'complete',
        contextApplied: 'yes', contextFingerprint: runtime?.context_fingerprint ?? fingerprint,
        memoryCount: runtime?.memory_count ?? 0, narrativeCount: runtime?.narrative_count ?? 0,
        knowledgeCount: runtime?.knowledge_count ?? 0, selectedCount: runtime?.selected_count ?? 0,
        droppedCount: runtime?.dropped_count ?? 0, contextTokens: runtime?.context_tokens ?? 0,
        contextRefreshes: current.contextRefreshes + 1, conversationRuntime: 'single-convai-client',
      }));

      // Exactly one Convai turn for exactly one player question. The backend
      // response text is intentionally not sent to Convai as a second prompt.
      // Convai generates the character response and plays the character's own
      // configured voice through WebRTC/AudioRenderer.
      client.sendUserTextMessage(trimmed);
      setUiState('READY');
    } catch (caughtError) {
      setError(safeErrorMessage(caughtError));
      setUiState('ERROR');
    } finally {
      questionInFlightRef.current = false;
    }
  }, [convaiCharacterId]);

  const interruptForExplicitUserTurn = useCallback(() => {
    const client = clientRef.current;
    if (!client || !client.state.isConnected || !shouldInterruptForExplicitUserTurn(client.state)) return false;
    activeNpcResponseActorIdRef.current = null;
    responseStartedForCurrentActorRef.current = false;
    interruptCurrentResponse(client);
    return true;
  }, []);

  const stop = useCallback(async () => {
    if (stoppingRef.current) return;
    if (!sessionIdRef.current && !clientRef.current) { setUiState('COMPLETED'); return; }
    stoppingRef.current = true;
    const lifecycleId = ++lifecycleIdRef.current;
    setUiState('STOPPING');
    setError(null);
    setDiagnostics((current) => ({ ...current, transcript: 'saving' }));
    await clearConvai();
    const token = backendTokenRef.current;
    const sessionId = sessionIdRef.current;
    if (token && sessionId) {
      try {
        const response = await endSession(token, sessionId, {
          turns: transcriptRef.current.map((turn) => ({
            role: turn.speaker === 'actor' ? 'user' : 'assistant', content: turn.text, timestamp: turn.timestamp,
          })),
        });
        if (lifecycleId !== lifecycleIdRef.current) return;
        setDiagnostics((current) => ({ ...current, transcript: 'saved' }));
        setTranscriptSaveMessage(response.memory_runtime.error ? 'Transcript saved; backend memory processing reported a non-fatal error.' : 'Transcript saved and backend memory processing completed.');
      } catch (caughtError) {
        if (lifecycleId !== lifecycleIdRef.current) return;
        setDiagnostics((current) => ({ ...current, transcript: 'error' }));
        setError(`Transcript persistence failed: ${safeErrorMessage(caughtError)}`);
      }
    }
    sessionIdRef.current = null;
    backendTokenRef.current = null;
    backendTokenExpiresAtRef.current = null;
    questionInFlightRef.current = false;
    contextAppliedRef.current = false;
    setUiState('COMPLETED');
    stoppingRef.current = false;
  }, [clearConvai]);

  const reset = useCallback(async () => {
    lifecycleIdRef.current += 1;
    await clearConvai();
    resetRuntime();
    setConvaiCharacterId(null);
    setUiState('IDLE');
  }, [clearConvai, resetRuntime]);

  useEffect(() => () => {
    lifecycleIdRef.current += 1;
    unsubscribeRef.current?.();
    const client = clientRef.current;
    clientRef.current = null;
    if (client) void disconnectConvai(client);
  }, []);

  return {
    uiState,
    knowledgeQuery: '',
    setKnowledgeQuery: () => undefined,
    messages,
    session,
    error,
    transcriptSaveMessage,
    diagnostics,
    start,
    sendText,
    interruptForExplicitUserTurn,
    stop,
    reset,
    convaiClient,
    convaiCharacterId,
  };
}
