import { describe, expect, it, vi, beforeEach } from 'vitest';
import { requestJson } from './backendClient';
import { refreshSessionContext } from './sessionApi';

vi.mock('./backendClient', () => ({
  requestJson: vi.fn(),
}));

describe('refreshSessionContext', () => {
  beforeEach(() => vi.clearAllMocks());

  it('refreshes context without changing the active session id', async () => {
    const response = {
      session_id: 'session-1',
      context: { dynamic_context: { status: 'complete', text: 'grounded context' } },
    };
    vi.mocked(requestJson).mockResolvedValue(response as never);

    const result = await refreshSessionContext('bearer', 'session-1', 'What is in the knowledge base?');

    expect(result.session_id).toBe('session-1');
    expect(requestJson).toHaveBeenCalledWith('/v1/session/context/refresh', {
      method: 'POST',
      bearerToken: 'bearer',
      body: {
        session_id: 'session-1',
        knowledge_query: 'What is in the knowledge base?',
      },
      signal: undefined,
    });
  });
});
