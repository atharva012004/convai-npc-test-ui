import { requestJson } from './backendClient';
import type { BootstrapResponse, SessionEndResponse, SessionStartResponse } from '../types/backend';

export function bootstrapSessionForIdentity(
  assertion: string,
  characterExternalId: string,
  actorExternalId: string,
  signal?: AbortSignal,
): Promise<BootstrapResponse> {
  return requestJson<BootstrapResponse>('/v1/client/session/bootstrap', {
    method: 'POST',
    gameAssertion: assertion,
    body: {
      character_external_id: characterExternalId,
      actor_external_id: actorExternalId,
    },
    signal,
  });
}

export function startSession(
  token: string,
  characterExternalId: string,
  actorExternalId: string,
  knowledgeQuery: string,
  signal?: AbortSignal,
): Promise<SessionStartResponse> {
  return requestJson<SessionStartResponse>('/v1/session/start', {
    method: 'POST',
    bearerToken: token,
    body: {
      character_external_id: characterExternalId,
      actor_external_id: actorExternalId,
      knowledge_query: knowledgeQuery.trim() || null,
    },
    signal,
  });
}

export interface SessionContextRefreshResponse {
  session_id: string;
  context: SessionStartResponse['context'];
}

export function refreshSessionContext(
  token: string,
  sessionId: string,
  knowledgeQuery: string,
  signal?: AbortSignal,
): Promise<SessionContextRefreshResponse> {
  return requestJson<SessionContextRefreshResponse>('/v1/session/context/refresh', {
    method: 'POST',
    bearerToken: token,
    body: { session_id: sessionId, knowledge_query: knowledgeQuery.trim() },
    signal,
  });
}

export function endSession(
  token: string,
  sessionId: string,
  transcript: { turns: Array<{ role: 'user' | 'assistant'; content: string; timestamp?: string }> },
  signal?: AbortSignal,
): Promise<SessionEndResponse> {
  return requestJson<SessionEndResponse>('/v1/session/end', {
    method: 'POST',
    bearerToken: token,
    body: {
      session_id: sessionId,
      transcript,
    },
    signal,
  });
}
