import { requestJson } from './backendClient';
import type { ConversationRuntimeDiagnostics } from '../types/backend';

export interface DirectConversationResponse {
  session_id: string;
  character_external_id: string;
  response: string;
  audio_base64: string | null;
  audio_content_type: string | null;
  voice_error: string | null;
  runtime: ConversationRuntimeDiagnostics | null;
}

export function sendDirectConversation(
  bearerToken: string,
  characterExternalId: string,
  actorExternalId: string,
  message: string,
  generateResponse = true,
  signal?: AbortSignal,
): Promise<DirectConversationResponse> {
  return requestJson<DirectConversationResponse>('/v1/conversation', {
    method: 'POST',
    bearerToken,
    body: {
      character_external_id: characterExternalId,
      actor_external_id: actorExternalId,
      message: message.trim(),
      generate_response: generateResponse,
    },
    signal,
  });
}
